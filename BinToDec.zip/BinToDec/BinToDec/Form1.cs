﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace BinToDec
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string[] lines;
        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();

            try
            {
                if (openFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    lines = File.ReadAllLines(openFileDialog1.FileName);
                    foreach (string line in lines)
                        textBox1.AppendText(line + '\n');
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            try
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    StreamWriter sw = new StreamWriter(saveFileDialog1.FileName);
                    sw.Write(textBox2.Text);
                    sw.Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (string line in lines)
                {
                    string exponent = Convert.ToString(line);
                    int fromBase = 10;
                    int toBase = 2;

                    String result = Convert.ToString(Convert.ToInt32(exponent, fromBase), toBase);

                    textBox2.AppendText(result + '\n');
                }
            }
            catch(OverflowException exx)
            {
                MessageBox.Show(exx.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }



        }





        private void autorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Program napisany przez Jakuba Sachajko");
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void clearToolStripMenuItem_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                foreach (string line in lines)
                {
                    string exponent = Convert.ToString(line);
                    int fromBase = 2;
                    int toBase = 10;

                    String result = Convert.ToString(Convert.ToInt32(exponent, fromBase), toBase);

                    textBox2.AppendText(result + '\n');
                }
            }
            catch (OverflowException exx)
            {
                MessageBox.Show(exx.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Problem", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void clearToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }

        private void infoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Program ten zamienia liczby z systemu dwójkowego na dziesiętny i na odwrót");
        }
    }
}
